# PocketSmart AI

FastAPI + Jinja2 implementation of the supplied PocketSmart AI specification: Home Interior, Party Planning, Jewelry Planning, authentication, session data, recommendation history and Gemini multimodal integration.

## Windows PowerShell

```powershell
cd PocketSmartAI
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
# edit .env and set GEMINI_API_KEY
python run.py
```

If PowerShell activation fails, use the venv executable directly:

```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe run.py
```

Open http://127.0.0.1:8000 and API docs at http://127.0.0.1:8000/docs.

## Tests

```powershell
.\.venv\Scripts\python.exe -m pytest -q
```

## Gemini

The supplied document references Gemini 1.5 Flash Pro. The model name is configurable through `GEMINI_MODEL`; this project defaults to `gemini-2.5-flash`. If no API key is configured, the application still runs using deterministic demo catalog recommendations.

The platform catalogs are intentionally simulated rather than scraped. This makes the project stable for classroom/demo use and avoids undocumented third-party scraping dependencies.
