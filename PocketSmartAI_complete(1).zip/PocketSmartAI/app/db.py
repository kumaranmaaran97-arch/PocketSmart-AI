import sqlite3
from contextlib import contextmanager
from app.config import settings
SCHEMA = '''
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT,email TEXT UNIQUE NOT NULL,name TEXT NOT NULL,password_hash TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS recommendations (id INTEGER PRIMARY KEY AUTOINCREMENT,user_id INTEGER NOT NULL,planner TEXT NOT NULL,request_json TEXT NOT NULL,result_json TEXT NOT NULL,created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,FOREIGN KEY(user_id) REFERENCES users(id));
'''
def init_db():
    with sqlite3.connect(settings.database_path) as conn: conn.executescript(SCHEMA)
@contextmanager
def get_db():
    conn=sqlite3.connect(settings.database_path); conn.row_factory=sqlite3.Row
    try:
        yield conn; conn.commit()
    finally: conn.close()
