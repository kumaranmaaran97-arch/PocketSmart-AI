from pathlib import Path
from contextlib import asynccontextmanager
from fastapi import FastAPI,Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from app.config import settings
from app.db import init_db
from app.routers import auth,planners,history
BASE=Path(__file__).resolve().parent
@asynccontextmanager
async def lifespan(app):init_db();yield
app=FastAPI(title=settings.app_name,version="1.0.0",lifespan=lifespan)
app.add_middleware(CORSMiddleware,allow_origins=["http://127.0.0.1:8000","http://localhost:8000"],allow_credentials=True,allow_methods=["*"],allow_headers=["*"])
app.mount("/static",StaticFiles(directory=str(BASE/"static")),name="static");templates=Jinja2Templates(directory=str(BASE/"templates"))
app.include_router(auth.router);app.include_router(planners.router);app.include_router(history.router)
@app.get("/health")
def health():return {"status":"ok","app":settings.app_name,"gemini_configured":bool(settings.gemini_api_key),"model":settings.gemini_model}
@app.get("/startup")
def startup():init_db();return {"status":"initialized"}
def page(name,title):
 def f(request:Request):return templates.TemplateResponse(name,{"request":request,"title":title})
 return f
app.add_api_route("/",page("index.html","PocketSmart AI"),methods=["GET"],response_class=HTMLResponse)
app.add_api_route("/login",page("login.html","Login"),methods=["GET"],response_class=HTMLResponse)
app.add_api_route("/register",page("register.html","Register"),methods=["GET"],response_class=HTMLResponse)
app.add_api_route("/dashboard",page("dashboard.html","Dashboard"),methods=["GET"],response_class=HTMLResponse)
app.add_api_route("/home-planner",page("home_planner.html","Home Planner"),methods=["GET"],response_class=HTMLResponse)
app.add_api_route("/party-planner",page("party_planner.html","Party Planner"),methods=["GET"],response_class=HTMLResponse)
app.add_api_route("/jewelry-planner",page("jewelry_planner.html","Jewelry Planner"),methods=["GET"],response_class=HTMLResponse)
