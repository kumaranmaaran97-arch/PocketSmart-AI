from fastapi import APIRouter,HTTPException,Request
from fastapi.responses import JSONResponse
from app.schemas import RegisterRequest,LoginRequest,normalize_email
from app.security import hash_password,verify_password,create_access_token,get_current_user
from app.db import get_db
router=APIRouter()
def cookie_response(payload,token):
 r=JSONResponse(payload);r.set_cookie("access_token",token,httponly=True,samesite="lax",max_age=86400);return r
@router.post("/register")
def register(d:RegisterRequest):
 e=normalize_email(d.email)
 with get_db() as db:
  if db.execute("SELECT id FROM users WHERE email=?",(e,)).fetchone():raise HTTPException(409,"Email already registered")
  uid=db.execute("INSERT INTO users(email,name,password_hash) VALUES(?,?,?)",(e,d.name.strip(),hash_password(d.password))).lastrowid
 return cookie_response({"message":"Registration successful"},create_access_token(uid,e))
@router.post("/login")
def login(d:LoginRequest):
 e=normalize_email(d.email)
 with get_db() as db:u=db.execute("SELECT * FROM users WHERE email=?",(e,)).fetchone()
 if not u or not verify_password(d.password,u["password_hash"]):raise HTTPException(401,"Invalid email or password")
 return cookie_response({"message":"Login successful","user":{"id":u["id"],"email":u["email"],"name":u["name"]}},create_access_token(u["id"],e))
@router.post("/logout")
def logout():
 r=JSONResponse({"message":"Logged out"});r.delete_cookie("access_token");return r
@router.post("/token")
def token(d:LoginRequest):
 e=normalize_email(d.email)
 with get_db() as db:u=db.execute("SELECT * FROM users WHERE email=?",(e,)).fetchone()
 if not u or not verify_password(d.password,u["password_hash"]):raise HTTPException(401,"Invalid credentials")
 return {"access_token":create_access_token(u["id"],e),"token_type":"bearer"}
@router.get("/session-info")
def info(request:Request):
 try:return {"logged_in":True,"user":get_current_user(request)}
 except HTTPException:return {"logged_in":False,"user":None}
@router.get("/session-data")
def data(request:Request):
 u=get_current_user(request)
 with get_db() as db:c=db.execute("SELECT COUNT(*) c FROM recommendations WHERE user_id=?",(u["id"],)).fetchone()["c"]
 return {"user":u,"recommendation_count":c}
