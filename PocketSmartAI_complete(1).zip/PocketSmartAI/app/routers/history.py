import json
from fastapi import APIRouter,Depends,HTTPException
from app.db import get_db
from app.security import get_current_user
router=APIRouter()
@router.get("/history")
def history(u=Depends(get_current_user)):
 with get_db() as db: rows=db.execute("SELECT id,planner,request_json,result_json,created_at FROM recommendations WHERE user_id=? ORDER BY id DESC LIMIT 50",(u["id"],)).fetchall()
 return [{"id":r["id"],"planner":r["planner"],"request":json.loads(r["request_json"]),"result":json.loads(r["result_json"]),"created_at":r["created_at"]} for r in rows]
@router.get("/recommendations-details/{rid}")
def details(rid:int,u=Depends(get_current_user)):
 with get_db() as db:r=db.execute("SELECT * FROM recommendations WHERE id=? AND user_id=?",(rid,u["id"])).fetchone()
 if not r:raise HTTPException(404,"Recommendation not found")
 return {"id":r["id"],"planner":r["planner"],"request":json.loads(r["request_json"]),"result":json.loads(r["result_json"]),"created_at":r["created_at"]}
