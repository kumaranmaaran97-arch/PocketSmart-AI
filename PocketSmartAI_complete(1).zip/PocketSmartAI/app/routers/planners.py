from fastapi import APIRouter,Depends,File,Form,UploadFile,HTTPException
from app.schemas import HomeRequest,PartyRequest
from app.security import get_current_user
from app.services.recommendation_service import generate_home,generate_party,generate_jewelry
router=APIRouter()
@router.post("/generate-home")
def home(d:HomeRequest,u=Depends(get_current_user)):return generate_home(u["id"],d.model_dump())
@router.post("/generate-party")
def party(d:PartyRequest,u=Depends(get_current_user)):return generate_party(u["id"],d.model_dump())
@router.post("/generate-jewelry")
async def jewelry(budget:float=Form(...),occasion:str=Form(...),style:str=Form("Elegant"),color_preference:str=Form(""),notes:str=Form(""),outfit_image:UploadFile|None=File(None),u=Depends(get_current_user)):
 if budget<=0:raise HTTPException(422,"Budget must be greater than zero")
 img=None;mime=None
 if outfit_image:
  if outfit_image.content_type not in {"image/jpeg","image/png","image/webp"}:raise HTTPException(400,"Only JPG, PNG and WEBP images are allowed")
  img=await outfit_image.read()
  if len(img)>5*1024*1024:raise HTTPException(413,"Image must be 5 MB or smaller")
  mime=outfit_image.content_type
 d={"budget":budget,"occasion":occasion.strip(),"style":style.strip(),"color_preference":color_preference.strip(),"notes":notes.strip()}
 return generate_jewelry(u["id"],d,img,mime)
