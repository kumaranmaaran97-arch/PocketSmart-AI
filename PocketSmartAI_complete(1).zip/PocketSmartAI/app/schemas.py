from typing import List
from pydantic import BaseModel,Field
class RegisterRequest(BaseModel):
    name:str=Field(min_length=2,max_length=80); email:str=Field(min_length=5,max_length=160); password:str=Field(min_length=8,max_length=128)
class LoginRequest(BaseModel): email:str; password:str
class HomeItem(BaseModel): category:str=Field(min_length=2,max_length=80); quantity:int=Field(default=1,ge=1,le=50)
class HomeRequest(BaseModel):
    budget:float=Field(gt=0,le=10_000_000); rooms:List[str]=Field(min_length=1,max_length=10); style:str=Field(default="Modern",max_length=80); items:List[HomeItem]=Field(min_length=1,max_length=30); priorities:str=Field(default="Functionality, style and price",max_length=300)
class PartyRequest(BaseModel):
    budget:float=Field(gt=0,le=10_000_000); guests:int=Field(gt=0,le=10000); event_type:str=Field(min_length=2,max_length=80); venue:str="Open to suggestions"; city:str="Coimbatore"; food_preference:str="Mixed"; theme:str="Simple and elegant"
def normalize_email(e): return e.strip().lower()
