from datetime import datetime,timedelta,timezone
from jose import JWTError,jwt
from passlib.context import CryptContext
from fastapi import HTTPException,Request,status
from app.config import settings
from app.db import get_db
pwd_context=CryptContext(schemes=["bcrypt"],deprecated="auto")
ALGORITHM="HS256"
def hash_password(p): return pwd_context.hash(p)
def verify_password(p,h): return pwd_context.verify(p,h)
def create_access_token(user_id,email):
    exp=datetime.now(timezone.utc)+timedelta(days=1)
    return jwt.encode({"sub":str(user_id),"email":email,"exp":exp},settings.secret_key,algorithm=ALGORITHM)
def get_current_user(request:Request):
    token=request.cookies.get("access_token"); auth=request.headers.get("Authorization","")
    if not token and auth.lower().startswith("bearer "): token=auth.split(" ",1)[1]
    if not token: raise HTTPException(status_code=401,detail="Login required")
    try: payload=jwt.decode(token,settings.secret_key,algorithms=[ALGORITHM])
    except JWTError: raise HTTPException(status_code=401,detail="Invalid or expired token")
    with get_db() as db: user=db.execute("SELECT id,email,name,created_at FROM users WHERE id=?",(int(payload["sub"]),)).fetchone()
    if not user: raise HTTPException(status_code=401,detail="User not found")
    return dict(user)
