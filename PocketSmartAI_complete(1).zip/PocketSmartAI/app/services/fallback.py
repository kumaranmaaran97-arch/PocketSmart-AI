from app.catalog import CATALOG
def home_fallback(d):
 b=d["budget"]; out=[]
 for i in d["items"]:
  m=[x for x in CATALOG["home"] if i["category"].lower() in x["category"] or x["category"] in i["category"].lower()] or CATALOG["home"][:2]
  out += [{**p,"quantity":i["quantity"],"estimated_total":p["price"]*i["quantity"]} for p in m[:2]]
 return {"summary":f"A {d['style']} home plan for ₹{b:,.0f}, with a practical 10% contingency.","budget":b,"allocation":{"furniture":b*.4,"lighting":b*.15,"decor":b*.2,"storage":b*.15,"buffer":b*.1},"recommendations":out[:10],"tips":["Compare dimensions before purchase.","Keep 10% for delivery or installation.","Prioritize frequently used items."],"source":"local-demo-fallback"}
def party_fallback(d):
 b=d["budget"]; g=d["guests"]; c=min(b*.45,g*500); a={"catering":c,"decoration":b*.15,"venue":b*.2,"entertainment":b*.1}; a["buffer"]=b-sum(a.values())
 out=[]
 for p in CATALOG["party"]: out.append({**p,"estimated_total":p["price"]*g if p.get("unit")=="guest" else p["price"]})
 return {"summary":f"A {d['event_type']} plan for {g} guests in {d['city']} within ₹{b:,.0f}.","budget":b,"allocation":a,"recommendations":out,"tips":["Confirm availability before paying.","Keep buffer for tax and transport.","Ask caterers for package inclusions."],"source":"local-demo-fallback"}
def jewelry_fallback(d,image=False):
 b=d["budget"]; s=d["style"]; arr=sorted(CATALOG["jewelry"],key=lambda x:(s.lower() not in x["style"].lower(),x["price"]))
 out=[{**p,"fit_reason":f"Suitable for a {s.lower()} look."} for p in arr if p["price"]<=b][:5] or [{**p,"fit_reason":"Closest catalog match; verify final price."} for p in arr[:3]]
 return {"summary":f"{s} jewelry ideas for a {d['occasion']} occasion within ₹{b:,.0f}."+(" Outfit image considered." if image else ""),"budget":b,"allocation":{"primary_piece":b*.55,"secondary_piece":b*.25,"buffer":b*.2},"recommendations":out,"tips":["Match jewelry scale to neckline.","Check material, dimensions and returns.","Use one statement piece."],"source":"local-demo-fallback"}
