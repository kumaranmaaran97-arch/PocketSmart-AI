import json
from app.config import settings
from app.services.fallback import home_fallback,party_fallback,jewelry_fallback
try:
 from google import genai
 from google.genai import types
except Exception:
 genai=None; types=None
_client=None
def _get_client():
 global _client
 if not settings.gemini_api_key or genai is None:return None
 if _client is None:_client=genai.Client(api_key=settings.gemini_api_key)
 return _client
def _prompt(domain,data):
 return ("You are PocketSmart AI, a budget planning assistant. Return ONLY valid JSON with keys "
 "summary, budget, allocation, recommendations, tips, source. Each recommendation should contain "
 "name, platform, price, category, url and reason. Never claim live price/availability was verified. "
 "Keep suggested spend within the stated budget. Domain: "+domain+"\nINPUT:\n"+json.dumps(data,ensure_ascii=False))
def _json(text):
 text=(text or "").strip(); a=text.find("{"); b=text.rfind("}")
 return json.loads(text[a:b+1]) if a>=0 and b>a else None
def _generate(domain,data,image=None,mime=None):
 c=_get_client()
 if not c:return None
 contents=[_prompt(domain,data)]
 if image and types: contents.append(types.Part.from_bytes(data=image,mime_type=mime))
 r=c.models.generate_content(model=settings.gemini_model,contents=contents,config=types.GenerateContentConfig(temperature=.35,max_output_tokens=4096))
 return _json(r.text)
def home_recommendations(d):
 try:
  r=_generate("Home Interior",d)
  if r:r["source"]="gemini";return r
 except Exception:pass
 return home_fallback(d)
def party_recommendations(d):
 try:
  r=_generate("Party Planning",d)
  if r:r["source"]="gemini";return r
 except Exception:pass
 return party_fallback(d)
def jewelry_recommendations(d,image=None,mime=None):
 try:
  r=_generate("Jewelry",d,image,mime)
  if r:r["source"]="gemini";return r
 except Exception:pass
 return jewelry_fallback(d,bool(image))
