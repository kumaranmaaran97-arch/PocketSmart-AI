import json
from app.db import get_db
from app.services.gemini_utils import home_recommendations,party_recommendations,jewelry_recommendations
def save(uid,planner,request,result):
 with get_db() as db:
  return db.execute("INSERT INTO recommendations(user_id,planner,request_json,result_json) VALUES(?,?,?,?,?)",(uid,planner,json.dumps(request),json.dumps(result))).lastrowid
def generate_home(uid,d):
 r=home_recommendations(d);save(uid,"home",d,r);return r
def generate_party(uid,d):
 r=party_recommendations(d);save(uid,"party",d,r);return r
def generate_jewelry(uid,d,img=None,mime=None):
 r=jewelry_recommendations(d,img,mime);save(uid,"jewelry",d,r);return r
