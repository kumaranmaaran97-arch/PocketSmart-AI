import os
os.environ["DATABASE_PATH"]="./test_pocketsmart.db";os.environ["SECRET_KEY"]="test-secret";os.environ["GEMINI_API_KEY"]=""
from fastapi.testclient import TestClient
from app.main import app
from app.db import init_db
init_db();client=TestClient(app)
def test_health(): assert client.get("/health").json()["status"]=="ok"
def test_register_login_home():
 client.post("/register",json={"name":"Test User","email":"test@example.com","password":"password123"})
 assert client.post("/login",json={"email":"test@example.com","password":"password123"}).status_code==200
 r=client.post("/generate-home",json={"budget":50000,"rooms":["Living Room"],"style":"Modern","items":[{"category":"light","quantity":2}],"priorities":"price"})
 assert r.status_code==200 and r.json()["recommendations"]
def test_history_requires_login():
 client.post("/logout");assert client.get("/history").status_code==401
